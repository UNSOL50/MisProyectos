package com.miacademia.matricula;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MatriculaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MatriculaApiApplication.class, args);
	}

}
