package com.miacademia.matricula.repository;

import com.miacademia.matricula.model.Curso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CursoRepository extends JpaRepository<Curso, Integer> {
}