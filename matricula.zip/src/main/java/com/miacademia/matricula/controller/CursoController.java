package com.miacademia.matricula.controller;

import com.miacademia.matricula.model.Curso;
import com.miacademia.matricula.repository.CursoRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cursos")
public class CursoController {

    @Autowired
    private CursoRepository cursoRepository;

    // Obtener todos los cursos
    @GetMapping
    public List<Curso> getAllCursos() {
        return cursoRepository.findAll();
    }

    // Crear un nuevo curso
    @PostMapping
    public Curso createCurso(@Valid @RequestBody Curso curso) {
        return cursoRepository.save(curso);
    }

    // Actualizar un curso existente
    @PutMapping("/{id}")
    public ResponseEntity<Curso> updateCurso(@PathVariable Integer id, @Valid @RequestBody Curso curso) {
        return cursoRepository.findById(id)
                .map(cursoExistente -> {
                    cursoExistente.setNombre(curso.getNombre());
                    cursoExistente.setSiglas(curso.getSiglas());
                    cursoExistente.setEstado(curso.isEstado());
                    return ResponseEntity.ok(cursoRepository.save(cursoExistente));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // Eliminar un curso
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCurso(@PathVariable Integer id) {
        if (cursoRepository.existsById(id)) {
            cursoRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
