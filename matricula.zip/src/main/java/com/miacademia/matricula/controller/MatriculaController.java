package com.miacademia.matricula.controller;

import com.miacademia.matricula.model.Matricula;
import com.miacademia.matricula.repository.MatriculaRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/matriculas")
public class MatriculaController {

    @Autowired
    private MatriculaRepository matriculaRepository;

    // Obtener todas las matrículas
    @GetMapping
    public List<Matricula> getAllMatriculas() {
        return matriculaRepository.findAll();
    }

    // Crear una nueva matrícula
    @PostMapping
    public Matricula createMatricula(@Valid @RequestBody Matricula matricula) {
        matricula.setFechaMatricula(LocalDateTime.now()); // Asignar la fecha de matrícula actual
        return matriculaRepository.save(matricula);
    }

    // Actualizar una matrícula existente
    @PutMapping("/{id}")
    public ResponseEntity<Matricula> updateMatricula(@PathVariable Integer id, @Valid @RequestBody Matricula matricula) {
        return matriculaRepository.findById(id)
                .map(matriculaExistente -> {
                    matriculaExistente.setDetalleMatricula(matricula.getDetalleMatricula());
                    matriculaExistente.setEstado(matricula.isEstado());
                    return ResponseEntity.ok(matriculaRepository.save(matriculaExistente));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // Eliminar una matrícula por su ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMatricula(@PathVariable Integer id) {
        if (matriculaRepository.existsById(id)) {
            matriculaRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
