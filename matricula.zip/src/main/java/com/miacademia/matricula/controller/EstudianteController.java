package com.miacademia.matricula.controller;

import com.miacademia.matricula.model.Estudiante;
import com.miacademia.matricula.repository.EstudianteRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/estudiantes")
public class EstudianteController {

    @Autowired
    private EstudianteRepository estudianteRepository;

    // Obtener todos los estudiantes
    @GetMapping
    public List<Estudiante> getAllEstudiantes() {
        return estudianteRepository.findAll();
    }

    // Crear un nuevo estudiante
    @PostMapping
    public Estudiante createEstudiante(@Valid @RequestBody Estudiante estudiante) {
        return estudianteRepository.save(estudiante);
    }

    // Actualizar un estudiante existente
    @PutMapping("/{id}")
    public ResponseEntity<Estudiante> updateEstudiante(@PathVariable Integer id, @Valid @RequestBody Estudiante estudiante) {
        return estudianteRepository.findById(id)
                .map(e -> {
                    e.setNombres(estudiante.getNombres());
                    e.setApellidos(estudiante.getApellidos());
                    e.setDni(estudiante.getDni());
                    e.setEdad(estudiante.getEdad());
                    return ResponseEntity.ok(estudianteRepository.save(e));
                })
                .orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEstudiante(@PathVariable Integer id) {
        // Verificar si el estudiante existe antes de intentar eliminarlo
        if (estudianteRepository.existsById(id)) {
            estudianteRepository.deleteById(id); // Eliminar directamente por ID
            return ResponseEntity.noContent().build(); // Retorna 204 No Content si se elimina correctamente
        } else {
            return ResponseEntity.notFound().build(); // Retorna 404 Not Found si el estudiante no existe
        }
    }


}
