package com.miacademia.matricula.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
public class Matricula {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private LocalDateTime fechaMatricula;

    @ManyToOne
    private Estudiante estudiante;

    @OneToMany(cascade = CascadeType.ALL)
    private List<DetalleMatricula> detalleMatricula;

    private boolean estado;

    // Getters y Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public LocalDateTime getFechaMatricula() {
        return fechaMatricula;
    }

    public void setFechaMatricula(LocalDateTime fechaMatricula) {
        this.fechaMatricula = fechaMatricula;
    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(Estudiante estudiante) {
        this.estudiante = estudiante;
    }

    public List<DetalleMatricula> getDetalleMatricula() {
        return detalleMatricula;
    }

    public void setDetalleMatricula(List<DetalleMatricula> detalleMatricula) {
        this.detalleMatricula = detalleMatricula;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
}
