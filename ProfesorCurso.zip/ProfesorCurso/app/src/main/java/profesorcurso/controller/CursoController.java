package profesorcurso.controller;

import profesorcurso.model.Curso;
import profesorcurso.service.CursoService;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/cursos")
public class CursoController {
    private final CursoService cursoService;

    public CursoController(CursoService cursoService) {
        this.cursoService = cursoService;
    }

    @GetMapping
    public Flux<Curso> listar() {
        return cursoService.listarCursos();
    }

    @GetMapping("/{id}")
    public Mono<Curso> obtener(@PathVariable Integer id) {
        return cursoService.obtenerCurso(id);
    }

    @PostMapping
    public Mono<Curso> crear(@RequestBody Curso curso) {
        return cursoService.guardarCurso(curso);
    }

    @DeleteMapping("/{id}")
    public Mono<Void> eliminar(@PathVariable Integer id) {
        return cursoService.eliminarCurso(id);
    }
}
