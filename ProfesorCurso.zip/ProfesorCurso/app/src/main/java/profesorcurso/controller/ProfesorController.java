package profesorcurso.controller;

import profesorcurso.model.Profesor;
import profesorcurso.service.ProfesorService;
import profesorcurso.service.CursoService;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/profesores")
public class ProfesorController {
    private final ProfesorService profesorService;

    public ProfesorController(ProfesorService profesorService) {
        this.profesorService = profesorService;
    }

    @GetMapping
    public Flux<Profesor> listar() {
        return profesorService.listarProfesores();
    }

    @GetMapping("/{id}")
    public Mono<Profesor> obtener(@PathVariable Integer id) {
        return profesorService.obtenerProfesor(id);
    }

    @PostMapping
    public Mono<Profesor> crear(@RequestBody Profesor profesor) {
        return profesorService.guardarProfesor(profesor);
    }
    
    @DeleteMapping("/{id}")
    public Mono<Void> eliminar(@PathVariable Integer id) {
        return profesorService.eliminarProfesor(id);
    }
    
}
