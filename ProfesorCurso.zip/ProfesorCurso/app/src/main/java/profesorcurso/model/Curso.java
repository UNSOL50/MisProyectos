package profesorcurso.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;
import lombok.Data;

@Data
@Table("cursos")
public class Curso {
    @Id
    private Integer id;
    private String nombre;
    private String descripcion;
    private Integer profesorId;
}
