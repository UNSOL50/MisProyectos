package profesorcurso.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;
import lombok.Data;
import java.util.List;
import java.time.LocalDate; // Importa LocalDate
@Data
@Table("profesores")
public class Profesor {
    @Id
    private Long idProfesor;
    private String nombre = "Nombre por defecto"; // Valor por defecto
    private String email = "Email por defecto"; // Valor por defecto
    private String telefono = "121"; // Valor por defecto
    private String especialidad = "1"; // Valor por defecto
    private LocalDate fecha_registro = LocalDate.now(); // Valor por defecto (la fecha actual)



    // Constructor por defecto
    public Profesor() {
        this.nombre = "Nombre por defecto";
        this.email = "Email por defecto";
        this.telefono = "121";
        this.especialidad = "";
        this.fecha_registro = LocalDate.now();  // Fecha por defecto
    }
}
