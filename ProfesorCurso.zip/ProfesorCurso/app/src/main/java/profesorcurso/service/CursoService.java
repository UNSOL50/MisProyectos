package profesorcurso.service;

import profesorcurso.model.Curso;
import profesorcurso.repository.CursoRepository;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.util.List;


@Service
public class CursoService {
    private final CursoRepository cursoRepository;

    public CursoService(CursoRepository cursoRepository) {
        this.cursoRepository = cursoRepository;
    }

    public Flux<Curso> listarCursos() {
        return cursoRepository.findAll();
    }

    public Mono<Curso> obtenerCurso(Integer id) {
        return cursoRepository.findById(id);
    }

    public Mono<Curso> guardarCurso(Curso curso) {
        return cursoRepository.save(curso);
    }

    public Mono<Void> eliminarCurso(Integer id) {
        return cursoRepository.deleteById(id);
    }
    
}
