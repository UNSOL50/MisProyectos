package profesorcurso.service;

import profesorcurso.model.Profesor;
import profesorcurso.repository.ProfesorRepository;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class ProfesorService {
    private final ProfesorRepository profesorRepository;

    public ProfesorService(ProfesorRepository profesorRepository) {
        this.profesorRepository = profesorRepository;
    }

    public Flux<Profesor> listarProfesores() {
        return profesorRepository.findAll();
    }

    public Mono<Profesor> obtenerProfesor(Integer id) {
        return profesorRepository.findById(id);
    }

    public Mono<Profesor> guardarProfesor(Profesor profesor) {
        return profesorRepository.save(profesor);
    }

    public Mono<Void> eliminarProfesor(Integer id) {
        return profesorRepository.deleteById(id);
    }
}
